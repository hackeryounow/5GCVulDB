# OAI CN5G PCF — Session-AMBR operator cap bypass via BitRate integer overflow (wrap-to-zero)

| Field | Value |
|---|---|
| **Component** | OpenAirInterface 5G Core — PCF (`oai-pcf`) |
| **Affected role** | PCF · SM policy control / QoS Session-AMBR authorization (`Npcf_SMPolicyControl`) |
| **Tested version** | `oaisoftwarealliance/oai-pcf:develop` image `sha256:b388a90a4e9b…` (built 2026-09-29T11:25Z) |
| **Source commit** | `oai-cn5g-pcf` **11c3ed4** (2026-09-29, merge of `feat-n5-qos-support`); compose/policies from `oai-cn5g-fed` 7959cfd |
| **Deployment** | Isolated lane `oai-pcf-vul01` (oai-nrf + oai-pcf, **yaml** policy backend), see `deployments/` |
| **Protocol** | HTTP/2 SBI cleartext (h2c) · `Npcf_SMPolicyControl` v1 (3GPP TS 29.512) · BitRate type (TS 29.571 §5.2.2) |
| **Class (CWE)** | **CWE-190** Integer Overflow → **CWE-863** Incorrect Authorization. Corroborating same-root: **CWE-248** Uncaught Exception, **CWE-20** Improper Input Validation |
| **Impact** | Operator-configured Session-AMBR ceiling is silently bypassed; a session is authorized at an effectively unbounded bitrate. Malformed BitRate strings are also accepted (201) or turn into uncaught-exception 400s. |
| **Reproducibility** | **2 / 2** across a lane restart (deterministic); control differential reproduces the clamp on well-formed values |
| **Related CVE** | None known — new code path introduced by `feat-n5-qos-support` (not present in v2.2.0) |

---

### Summary

The PCF's QoS Session-AMBR authorization clamps a subscriber's subscribed Session-AMBR to the
operator-configured maximum (`qos_authorization.max_session_ambr_ul/dl`). The clamp converts the
3GPP `BitRate` string (e.g. `"200 Mbps"`) to an integer bits-per-second value with
`oai::utils::bitrate::to_bps()`. That conversion computes `stoull(number) * unit_multiplier` in
`uint64_t` **without any overflow check on the multiplication**. A `BitRate` whose magnitude is an
exact multiple of 2^64 after unit scaling (e.g. `"4503599627370496 Tbps"` = 2^52 × 10^12 ≡ 0 mod 2^64)
silently **wraps to 0 bps**.

Because the wrapped value equals 0, the clamp logic concludes "no reduction happened" and returns the
**original, un-clamped** string verbatim as the authorized Session-AMBR. The result: a session that
should be capped at (e.g.) 100 Mbps is authorized at `4503599627370496 Tbps`, i.e. the operator ceiling
is completely bypassed. The same missing input validation on `BitRate` strings additionally (a) accepts
arbitrary garbage as a valid bitrate (HTTP 201) and (b) lets a >19-digit fractional part escape as an
**uncaught `std::out_of_range`** (HTTP 400 after the request has already mutated server state).

### Details

**Root cause — silent unsigned-overflow in `to_bps()` (`src/common/utils/bitrate.hpp:44-89`):**

```cpp
uint64_t bps = 0;
try {
  bps = std::stoull(m[1].str()) * multiplier;   // :71  multiply CAN overflow uint64 silently
} catch (const std::exception&) {
  return std::nullopt;                          // only catches stoull's own out_of_range
}
...
if (m[2].matched) {
  ...
  const uint64_t frac_value = std::stoull(frac); // :84  NOT inside any try -> uncaught throw
  bps += (frac_value * multiplier) / denom;
}
```

The `try` block only guards `stoull` itself (which throws when the *integer text* exceeds 2^64). The
subsequent `* multiplier` is an unsigned multiply that **wraps modulo 2^64 with no diagnostic**. For
`"4503599627370496 Tbps"`: `stoull("4503599627370496")` = 2^52 (fits), then `2^52 * 10^12`
= 2^52 × (2^12·5^12) = 2^64·5^12 ≡ **0**. So `to_bps()` returns `optional(0)` — a *valid* 0 bps, not
`nullopt`.

**Bypass — `clamp_bitrate()` returns the subscribed string unchanged (`src/pcf_app/sm_policy/qos_session_authorization.cpp:33-49`):**

```cpp
const std::optional<uint64_t> sub_bps = oai::utils::bitrate::to_bps(subscribed); // = optional(0)
if (!sub_bps) return subscribed;                       // :37 not taken (0 is a value)
uint64_t effective = *sub_bps;                         // 0
if (op_cap_bps) effective = std::min(effective, *op_cap_bps);  // :40 min(0, cap) = 0
if (vplmn_cap) { ... effective = std::min(effective, *v); }
if (effective == *sub_bps) return subscribed;          // :47 0 == 0 -> TRUE -> return ORIGINAL huge string
return oai::utils::bitrate::from_bps(effective);       // :48 never reached
```

The `effective == *sub_bps` shortcut at :47 is meant to preserve the original formatting when clamping
did not reduce the value. When the subscribed value wrapped to 0, `min(0, cap)` is still 0, so the guard
fires and the **original enormous string** is returned as the authorized Session-AMBR. This value is
written into the `SessionRule.authSessAmbr` returned to the SMF (TS 29.512 §4.2.6.6.1) and persisted on
the association for later Policy Authorization (TS 29.514 §4.1.3.1).

**Exact wrap-to-zero triggers** (value = 2^64 / unit-multiplier, one per unit):

| Unit | BitRate string that wraps to 0 bps |
|---|---|
| Tbps | `4503599627370496 Tbps` (2^52) |
| Gbps | `36028797018963968 Gbps` (2^55) |
| Mbps | `288230376151711744 Mbps` (2^58) |
| Kbps | `2305843009213693952 Kbps` (2^61) |

Note the bypass is specific to *wrap-to-zero*: a huge value that overflows to a non-zero remainder is
still clamped (`min(nonzero, cap) = cap`). Only the exact 2^64-multiple values defeat the ceiling — and
they are trivially computable.

**Corroborating defects in the same unvalidated-BitRate path** (confirmed in the same PoC run):

- **cand-05 — CWE-248 (uncaught exception).** The fractional `stoull(frac)` at `bitrate.hpp:84` is
  *outside* the `try`. A `BitRate` with a >19-digit fraction (e.g. `"1.99999999999999999999999 Mbps"`,
  23 nines) makes `to_bps()` throw `std::out_of_range`. The throw happens at
  `pcf_sm_policy_control.cpp:520` (`authorize_session_rule_into`) — i.e. **after** the request already
  mutated server-side association indexes at `:505` — and surfaces as an HTTP 400 on otherwise
  well-formed JSON. (This state mutation is the trigger for the companion leak report
  `VUL-20261012225126-POC`.)
- **cand-07 — CWE-20 (validation no-op).** `Ambr::validate()` (`src/common-src/model/Ambr.cpp:37-53`) is
  an empty stub, so a syntactically invalid `BitRate` such as `"!!!not-a-bitrate!!!"` is accepted and
  stored (HTTP 201) instead of being rejected.

**Log / trigger signature** (PCF, on a successful bypass — the authorized rule carries the huge value):

```
[pcf_app] [info] Authorized SessionRule 'SR-<n>' (authSessAmbr=set, authDefQos=unset) [TS 29.512 §4.2.6.6.1]
```
with the HTTP 201 response body containing
`"authSessAmbr":{"downlink":"4503599627370496 Tbps","uplink":"4503599627370496 Tbps"}` while the
operator cap log line reads `Max Session-AMBR Uplink/Downlink: 100 Mbps`.

### PoC

Isolated lane (no MySQL, no AMF/SMF/UPF — coexists with any baseline core):

```bash
cd deployments
docker compose -p oai-pcf-vul01 -f docker-compose.yaml up -d      # oai-nrf + oai-pcf (yaml backend)
# PCF SBI published on 127.0.0.1:18080 ; operator Session-AMBR cap = 100 Mbps (see pcf-config.yaml)
```

Run the parameterized PoC (drives `curl --http2-prior-knowledge`, since the SBI is h2c-only):

```bash
# single shot against the lane
python3 exploit/oai_sessambr_overflow_bypass_poc.py --target 127.0.0.1:18080 --cap-mbps 100 \
        --evidence-dir evidence_manual

# full harness: 2 runs across a lane restart, health-gated, with pcap + all-NF logs before/after
bash exploit/run_repro.sh
```

PoC scripts (source of truth — not inlined here):
- `exploit/oai_sessambr_overflow_bypass_poc.py` — sends a CONTROL (`200 Mbps`, expects clamp to
  `100 Mbps`), the three wrap-to-zero OVERFLOW units (expect the value returned verbatim = bypass), plus
  the cand-05 long-fraction (expect 400) and cand-07 garbage (expect 201) secondary probes. Key args:
  `--target` (default `127.0.0.1:18080`), `--cap-mbps` (operator cap, default 100), `--evidence-dir`,
  `--supi`, `--skip-secondary`. Exit 0 = REPRODUCED.
- `exploit/run_repro.sh` — reproduction harness: `run_once 1` → `docker compose restart` → health gate →
  `run_once 2`; captures pcap on the `oai-pcfvul` bridge and before/after logs for **all** lane NFs
  (oai-nrf, oai-pcf).

**Observed (both runs, `evidence_run1/`, `evidence_run2/`):**

| case | subscribed (`subsSessAmbr.uplink`) | HTTP | authorized `authSessAmbr.uplink` | expected |
|---|---|---|---|---|
| control | `200 Mbps` | 201 | **`100 Mbps`** (clamped) | clamp works on well-formed value |
| overflow_Tbps | `4503599627370496 Tbps` | 201 | **`4503599627370496 Tbps`** (verbatim) | **cap bypassed** |
| overflow_Gbps | `36028797018963968 Gbps` | 201 | **`36028797018963968 Gbps`** | **cap bypassed** |
| overflow_Mbps | `288230376151711744 Mbps` | 201 | **`288230376151711744 Mbps`** | **cap bypassed** |
| cand05_longfrac | `1.999…(23 nines)… Mbps` | **400** | — | uncaught `out_of_range` |
| cand07_garbage | `!!!not-a-bitrate!!!` | **201** | accepted | validation no-op |

Evidence per run: `verdict.txt` (`REPRODUCED`), `poc_summary.json`
(`control_clamped_to_cap=true`, `overflow_bypass_all_units=true`), the six `*_req_body.json` /
`*_resp_headers.txt` / `*_resp_body.json` triples, `pcap/` (66 packets), and `logs_before/` +
`logs_after/` for oai-nrf and oai-pcf. `run2` shows `registrations` 1→2 and `RestartCount=0`,
confirming a clean restart between the two reproductions.

### Impact

- **Authorization / QoS ceiling bypass (CWE-190 → CWE-863).** The operator's Session-AMBR maximum — a
  policy control the PCF is explicitly responsible for enforcing (TS 29.513 / TS 29.512 §4.2.6.6.1) — is
  silently defeated for wrap-to-zero `BitRate` values. A PDU session is authorized at an effectively
  unbounded bitrate, enabling bandwidth/QoS abuse, congestion or charging evasion. Any party able to
  influence the `subsSessAmbr` carried in `SmPolicyContextData` (a compromised or spoofed SMF on an
  unauthenticated SBI, a corrupted subscriber profile, or a rogue NF discovered via the NRF) can trigger
  it; the trigger is deterministic and needs no race or memory corruption.
- **Uncaught exception on well-formed input (CWE-248).** cand-05 turns a valid JSON request into an
  uncaught `std::out_of_range` (HTTP 400) *after* server state was mutated — an input-handling robustness
  defect and the trigger for the companion resource-leak report.
- **Missing input validation (CWE-20).** cand-07 accepts arbitrary non-numeric strings as bitrates,
  which can propagate malformed policy decisions downstream to the SMF.

**Suggested fixes (source-pointed):**
1. `src/common/utils/bitrate.hpp:71` — detect multiplication overflow before it wraps: reject (return
   `std::nullopt`) when `stoull(m[1]) > UINT64_MAX / multiplier` (or use `__builtin_mul_overflow` /
   a checked-multiply). Do the same for the fractional term at `:85`.
2. `src/common/utils/bitrate.hpp:84` — move the fractional `stoull(frac)` inside the `try` (or bound the
   fraction length) so a long fraction yields `nullopt` instead of throwing.
3. `src/pcf_app/sm_policy/qos_session_authorization.cpp:47` — do not infer "no clamping needed" from
   `effective == *sub_bps`; compare against the *cap* explicitly, and treat a 0 bps parse of a non-zero
   textual magnitude as invalid rather than as a legitimate 0.
4. `src/common-src/model/Ambr.cpp:37-53` — implement `Ambr::validate()` to enforce
   `BANDWIDTH_VALIDATION_REGEX` (and a sane upper bound) so malformed `BitRate` strings are rejected at
   the API boundary (400) before any state mutation.
