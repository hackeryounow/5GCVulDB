# VUL-20261002 — OAI CN5G PCF: integer overflow (wrap-to-zero) in BitRate parsing — Bug report (non-security)

## Classification

- **Type:** Bug — silent unsigned integer overflow (multiply wraps modulo 2^64); no security impact demonstrated
- **Component:** `oai-cn5g-pcf` — `oai::utils::bitrate::to_bps()` (`src/common/utils/bitrate.hpp:71`) and the Session-AMBR clamp path (`src/pcf_app/sm_policy/qos_session_authorization.cpp:32-49`)
- **Commit ID:** `11c3ed4163f6da9c694a38220c6598bbac530816` (`oai-cn5g-pcf` develop HEAD, 2026-09-29)

## Summary

The PCF converts 3GPP BitRate strings to integer bps with `std::stoull(number) * unit_multiplier` in
`uint64_t` — no overflow check on the multiplication (`bitrate.hpp:71`; the `try` only guards
`stoull`). A value that is an exact multiple of 2^64 after unit scaling (`"4503599627370496 Tbps"` =
2^52 × 10^12) wraps silently to **0 bps** as a *valid* parse result; `clamp_bitrate()` then computes
`min(0, cap) == 0`, takes its "value unchanged — preserve original string" shortcut and returns the
un-clamped string as `authSessAmbr`. Side quirks on the same path: a >19-digit fractional part throws
an uncaught `std::out_of_range` (`bitrate.hpp:84`, HTTP 400 on well-formed JSON), and unparseable
strings are preserved verbatim by design (`:38`).

Live verification shows no security effect: a request forged directly at the PCF SBI creates an
orphan policy association that never reaches the enforcement plane (UPF/RAN follow only the SMF's
own association; the `notificationUri` is never called back — zero callbacks on a listener); in the
reference deployment the PCF is not in the enforcement path at all (`use_local_pcc_rules: yes`); and
100+ repeated forged requests change only in-memory PCF state with no effect on any UE session. The
wrong value would propagate only if it arrived via the SMF's own create (corrupt subscription data /
compromised SMF) in a deployment that wires the PCF into QoS enforcement — outside the demonstrated
behaviour. Recorded as an integer-overflow bug, not a vulnerability.

## Steps to Reproduce (curl)

Download → extract → deploy → trigger, as a single block:

```bash
# 1) download + extract the bundle (bug report, deployment files, PCF source snapshot)
curl -L -o packages.tar.gz https://github.com/hackeryounow/5GCVulDB/raw/main/VUL-20261002-POC/packages.tar.gz
tar xzf packages.tar.gz && cd pkgs && B=$PWD

# 2) (re)start the core network — restart on every verification; shut down any other running core first
cd $B/deployments/develop
docker compose -p develop -f docker-compose-basic-nrf.yaml up -d      # re-verification: ... restart
cd $B

# 3) start the PCF with the operator cap (100 Mbps) and confirm the cap in its logs
docker rm -f oai-pcf 2>/dev/null
docker run -d --name oai-pcf --network demo-oai-public-net -p 127.0.0.1:18080:8080/tcp \
  -v "$B/deployments/pcf/pcf-config.yaml:/openair-pcf/etc/config.yaml" \
  -v "$B/deployments/pcf/policies:/openair-pcf/policies" \
  oaisoftwarealliance/oai-pcf:develop
docker logs oai-pcf 2>&1 | grep 'Max Session-AMBR'                    # -> 100 Mbps

# 4) control request — subscribed 2x cap must come back clamped
curl -s --http2-prior-knowledge -X POST http://127.0.0.1:18080/npcf-smpolicycontrol/v1/sm-policies \
  -H 'Content-Type: application/json' \
  -d '{"supi":"imsi-208950000000301","pduSessionId":1,"pduSessionType":"IPV4","dnn":"oai",
       "sliceInfo":{"sst":1,"sd":"000001"},"notificationUri":"http://127.0.0.1:9999/notify",
       "subsSessAmbr":{"uplink":"200 Mbps","downlink":"200 Mbps"}}' \
  | python3 -c "import json,sys; print(list(json.load(sys.stdin)['sessRules'].values())[0]['authSessAmbr'])"
# -> {"downlink": "100 Mbps", "uplink": "100 Mbps"}

# 5) overflow request — same call with a wrap-to-zero value (2^52 x 10^12 = 0 mod 2^64);
#    the un-clamped string is echoed back: the bug
curl -s --http2-prior-knowledge -X POST http://127.0.0.1:18080/npcf-smpolicycontrol/v1/sm-policies \
  -H 'Content-Type: application/json' \
  -d '{"supi":"imsi-208950000000302","pduSessionId":2,"pduSessionType":"IPV4","dnn":"oai",
       "sliceInfo":{"sst":1,"sd":"000001"},"notificationUri":"http://127.0.0.1:9999/notify",
       "subsSessAmbr":{"uplink":"4503599627370496 Tbps","downlink":"4503599627370496 Tbps"}}' \
  | python3 -c "import json,sys; print(list(json.load(sys.stdin)['sessRules'].values())[0]['authSessAmbr'])"
# -> {"downlink": "4503599627370496 Tbps", "uplink": "4503599627370496 Tbps"}
```

Steps 3–5 verified live (2026-10-16/17) against this exact deployment; the extracted
`deployments/` copy is byte-identical to the verified environment. The repository bundle root also
carries `oai_sessambr_overflow_bypass_poc.py`, which automates the same differential.

## Logs

Verification run 2026-10-16 — operator cap at startup, PCF side of the requests, response
differential:

```
[2026-10-16 16:47:11.222] [config ] [info]     + Max Session-AMBR Uplink....................: 100 Mbps
[2026-10-16 16:47:11.222] [config ] [info]     + Max Session-AMBR Downlink..................: 100 Mbps
[2026-10-16 16:47:34.079] [pcf_app] [info] Authorized SessionRule 'SR-1' (authSessAmbr=set, authDefQos=unset) [TS 29.512 §4.2.6.6.1]
[2026-10-16 16:47:34.181] [pcf_sbi] [warning] Parsing error: stoull          # >19-digit fractional probe -> HTTP 400

CONTROL  (subsSessAmbr = "200 Mbps"):              "authSessAmbr":{"downlink":"100 Mbps","uplink":"100 Mbps"}
OVERFLOW (subsSessAmbr = "4503599627370496 Tbps"): "authSessAmbr":{"downlink":"4503599627370496 Tbps","uplink":"4503599627370496 Tbps"}
```

## Affected Versions

- **Tested live (2026-10-16):** `oaisoftwarealliance/oai-pcf:develop`, digest
  `sha256:45f9b6c1ebd938c9da86a5c104b30c64d1ee22b35f7cdc6d728c514bc2ef9537` (built 2026-09-29;
  upstream develop HEAD still `11c3ed4` — unfixed).
- **Scope:** path introduced by `feat-n5-qos-support` (merge `11c3ed4`, 2026-09-29); v2.2.0
  predates it.

## Impact

No security impact demonstrated. Functional impact: crafted BitRate inputs yield an un-clamped
authorized Session-AMBR, and a >19-digit fraction aborts an otherwise well-formed request. Fix:
check the multiply in `to_bps()` and move the fractional `stoull` inside the `try`.
